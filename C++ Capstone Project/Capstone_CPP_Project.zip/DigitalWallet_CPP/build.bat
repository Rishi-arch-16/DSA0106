@echo off
g++ -std=c++17 -O2 main.cpp -o DigitalWallet.exe -mwindows -lcomctl32
if errorlevel 1 (
  echo Build failed. Check that MinGW-w64 GCC is installed and g++ is on PATH.
  pause
  exit /b 1
)
echo Build successful. Run DigitalWallet.exe
pause
