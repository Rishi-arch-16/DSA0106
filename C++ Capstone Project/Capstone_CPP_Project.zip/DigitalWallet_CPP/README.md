# Digital Wallet and Money Transfer System (C++)

A Windows desktop GUI capstone demo built in C++ using the native Win32 API and text-file storage. It does not require Qt, SQLite, a web server, or paid services.

## Features

- Create a wallet with a generated user ID and wallet ID
- Login using mobile number and 4-8 digit PIN
- Deposit simulated funds
- Transfer funds to another active wallet
- Validate positive amounts, receiver wallet, available balance, self-transfers, and transfer limit
- View transaction history
- Change PIN
- Persist users and transactions between application runs

## Requirements

- Windows 10/11
- MinGW-w64 GCC (g++) with the Windows API headers
- Visual Studio Code (optional; any editor can be used)

## Build

Open this folder in VS Code. Open the terminal in this folder and run:

```powershell
g++ -std=c++17 -O2 main.cpp -o DigitalWallet.exe -mwindows -lcomctl32
```

Or double-click `build.bat` after installing MinGW and adding `g++` to PATH.

Then run:

```powershell
.\DigitalWallet.exe
```

## First live demo (two users)

1. Start the app.
2. In the registration panel, enter:
   - Name: Asha
   - Mobile: 9876543210
   - PIN: 1234
3. Click **Create Wallet**. Note the displayed Wallet ID (usually WAL0001 for a fresh data folder).
4. Register a second user:
   - Name: Kavin
   - Mobile: 9876543211
   - PIN: 2345
5. Log in as Asha using mobile `9876543210` and PIN `1234`.
6. Deposit `5000` and click **Add Money**.
7. Enter amount `1000`, enter Kavin's wallet ID in the receiver field, and click **Transfer Money**.
8. The balance should show Rs. 4000.00. The transaction history should show the deposit and transfer.
9. Log out and log in as Kavin. His balance should show Rs. 1000.00.
10. Try to transfer more than the available balance to demonstrate validation.

Wallet IDs are generated based on the number of existing records. If you have previously run the app, use the wallet IDs shown during registration rather than assuming WAL0001/WAL0002.

## Data files

The app creates these files in the same working directory as the executable:

- `users.txt` - user, wallet, PIN, balance and active status
- `transactions.txt` - transaction ID, date/time, type, sender, receiver, amount and status

Keep these files in the same folder as the executable. Back them up before deleting or editing them.

## Important limitations

This is an academic simulation. It does not connect to banks, UPI, cards, or real payment networks. Deposits create demo funds; no actual money moves.

PINs are stored as plain text in `users.txt` to keep this beginner-friendly file-handling demonstration inspectable. Use only fictional demo credentials. This implementation is not suitable for real financial use. A production system would need secure password hashing, encryption, database transactions, audit controls, fraud monitoring, and regulated payment integrations.

## Suggested project modules

1. Wallet Creation and Fund Management
2. Payment and Money Transfer
3. Transaction Validation and History
4. Security and Account Management
